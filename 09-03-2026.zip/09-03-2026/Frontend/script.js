const apiUrl = "http://localhost:5107/api/todo";

function loadTasks() {
    fetch(apiUrl)
    .then(res => res.json())
    .then(data => {
        const list = document.getElementById("taskList");
        list.innerHTML = "";

        data.forEach(task => {
            const li = document.createElement("li");

            li.innerHTML = `
            <input type="checkbox" ${task.isCompleted ? "checked" : ""}>
            ${task.title}
            <button onclick="deleteTask(${task.id})">Delete</button>
            `;

            list.appendChild(li);
        });
    });
}

function addTask() {
    const title = document.getElementById("taskInput").value;

    fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            title: title,
            isCompleted: false
        })
    }).then(() => loadTasks());
}

function deleteTask(id) {
    fetch(apiUrl + "/" + id, {
        method: "DELETE"
    }).then(() => loadTasks());
}

loadTasks();